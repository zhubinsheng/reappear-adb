import { build } from '@config/index.js'

export const hotPublishConfig = {
    url: build.hotPublishUrl,
    configName: build.hotPublishConfigName
}