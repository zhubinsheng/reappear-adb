
const template = {
  state: {},

  mutations: {},

  actions: {}
}

export default template
