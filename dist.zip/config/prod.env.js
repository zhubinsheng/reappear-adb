module.exports = {
  NODE_ENV: '"production"',
  BASE_API: 'http://127.0.0.1:25565'
}
