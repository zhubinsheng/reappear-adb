
var iconvLite = require('iconv-lite');
var device;
const getHidDev = sender => {
    
}

const onHidData = sender => {
   
}

export default {
	getHidDev,onHidData
}